#plugin 1.0.0 

Full list of what this plugin is about

*word replacement 

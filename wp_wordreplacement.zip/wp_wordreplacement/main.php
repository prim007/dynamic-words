<?php

/**

* @package Dynamic Word Replacement

* @version 1.0.0

*/


/*

Plugin Name: Dynamic Word Replacement

Plugin URI: https://dynamicwordreplacement.co.za

Description: Word replacement in your posts and pages.

Version: 1.0.0

Author: Primrose

Author URI: https://prim.com

Text Domain: wp_wordreplacement

*/

if( ! defined( 'ABSPATH' )) {
    die;
}

if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php') ) {
require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}

/*IDENTIFY PLUGIN PATH*/
define( 'PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PLUGIN', plugin_basename( __FILE__ ) );


use includes\base\activate;
use includes\base\deactivate;


function activate_wp_wordreplacement(){
    Activate::activate();
  }

function  deactivate_wp_wordreplacement(){
    Deactivate::deactivate();
  }

register_activation_hook(__FILE__, array( 'Activate', 'activate') );
register_deactivation_hook(__FILE__, array( 'Deactivate', 'deactivate') );

if (class_exists( 'includes\\Init' ) ) {

    includes\Init::register_services();
}
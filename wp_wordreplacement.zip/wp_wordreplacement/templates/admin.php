<h1>Test if code responds Dynamic Word Replacement</h1>

<form action="/">
  <label for="addword">Add Word to be changed:</label>
  <input type="text" id="" name=""><br><br>
  <label for="replaceword">Word that replaces the word(s) changed</label>
  <input type="" id="" name=""><br><br>
  <input type="submit" value="Submit">
</form>

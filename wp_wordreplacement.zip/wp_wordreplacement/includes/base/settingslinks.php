<?php

/**

* @package Dynamic Word Replacement

* @version 1.0.0

*/
namespace includes\base;

class settingslinks {

    protected $plugin;

    public function __construct()
    {

    $this->plugin = PLUGIN;
}


    public function register() {

        add_filter( "plugin_action_links_$this->plugin", array ($this, 'settings_link') );

}

   public function settings_link( $links ) {

    $settings_link = '<a href="admin.php?all&page=plugin_status=all&paged=1&s">Settings</a>';
    array_push( $link, $settings_link );
    return $links;
   }

}
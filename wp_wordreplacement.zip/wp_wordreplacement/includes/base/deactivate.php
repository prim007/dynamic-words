<?php

/**

* @package Dynamic Word Replacement

* @version 1.0.0

*/

namespace includes\base;

class deactivate {
    public static function deactivate() {

        flush_rewrite_rules();
        
    }
}
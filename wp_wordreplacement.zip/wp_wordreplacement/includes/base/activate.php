<?php

/**

* @package Dynamic Word Replacement

* @version 1.0.0

*/
namespace includes\base;

class activate {
    public static function activate() {

flush_rewrite_rules();

    }
}
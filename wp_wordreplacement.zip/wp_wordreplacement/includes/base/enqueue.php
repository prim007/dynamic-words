<?php

/**

* @package Dynamic Word Replacement

* @version 1.0.0

*/
namespace includes\base;


class enqueue {
    

    public function register() {
        add_action( 'admin_enquene_scripts', array( $this, 'enqueue' ) );
    }

    function enqueue(){
    //enqueue all scripts
    wp_enqueue_style( 'pluginstyle', PLUGIN_URL . 'assests/styles.css' );
    wp_enqueue_style( 'pluginscripts', PLUGIN_URL .'assests/myscripts.js' );
    
 }
}
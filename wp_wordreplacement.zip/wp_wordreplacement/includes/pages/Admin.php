<?php

/**

* @package Dynamic Word Replacement

* @version 1.0.0

*/
namespace includes\pages;

use\includes\api\settingsapi;


class Admin {

   

    public function register() {
    add_action( 'admin_menu', array( $this, 'add_admin_pages' ) );
    }
    
    public function add_admin_pages(){
    add_menu_page( 'Dynamic', 'Dynamic Word Replace', 'manage_options', 'replace_word', array( $this, 'admin_index' ), '', null );
    }

    public function admin_index() {
    require_once PLUGIN_PATH . 'templates/admin.php';
    }
}